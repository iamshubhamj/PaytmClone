'use strict';
var path = require('path');
var server = require(path.resolve(__dirname, '../..'));
var request = require('request');
var datasource = server.datasources.loopback;

module.exports = function (AdminView) {


    ///////////////////////////// Admin Registration //////////////////////////////


    AdminView.AdminRegistration = function (data, cb) {
       
        var phn_Num = data.phoneNumber;
        var password = data.password;
        var email_Id = data.emailId;
       

        var postData = {
            "phoneNumber": phn_Num,
            "password": password,
            "emailId": email_Id
        }

        var merchant = postData;

        AdminView.findOne({ where: { phoneNumber: phn_Num } }, function (err, res) {

            if (res) {

                AdminView.upsert(merchant, (err, respo) => {
                    if (err) return err;
                    cb(null, respo);

                });
             

            }
            else {
                console.log("else");
                AdminView.create(merchant, (err, respo) => {
                    if (err) return err;
                    cb(null, respo)
                });
            }
        });
    }

    AdminView.remoteMethod('AdminRegistration', {
        http: { path: '/admin_signup', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }
    });

    /////////////////////////////// Admin Login /////////////////////////////

    AdminView.AdmincheckCredentials = function (data, cb) {


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        var phoneNumber = data.phoneNumber;
        var password = data.password;


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        AdminView.findOne({ where: { phoneNumber: phoneNumber, password: password } }, function (err, res) {

            if (res != null) {
                var response = {
                    "PhoneNumber": res.phoneNumber,
                    "Status": "Success",
                    "Message": "Login Successfully done."
                };
                cb(null, response)
            } else {

                cb(null, { "Message": "Login Failed. Please check Credentials." });
                return;

            }


        }
        )
    }


    AdminView.remoteMethod('AdmincheckCredentials', {
        http: { path: '/admin_login', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })


    ///////////////////////// Load Wallet ////////////////////////
/*
Load all txn from other api from diffrent schema.
*/
    AdminView.UserWalletBalance = function (data, cb) {
        var phoneNumber = data.phoneNumber;
        var walletBalance = data.walletBalance;
        var addBalData = {
            "phoneNumber": phoneNumber,
            "walletBalance": walletBalance
        }
        AdminView.findOne({ where: { phoneNumber: phoneNumber } }, function (err, res) {

            if (res) {

                AdminView.upsert(addBalData, (err, respo) => {
                    if (err) return err;
                    cb(null, respo);

                });
             

            }
            else {
             
                AdminView.create(addBalData, (err, respo) => {
                    if (err) return err;
                    cb(null, respo)
                });
            }
        });
    
    }



    AdminView.remoteMethod('UserWalletBalance', {
        http: { path: '/loadWallet', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })

    //////////////////////////// Admin View All Txn ////////////////////////////////

    AdminView.UserWalletBalance = function (data, cb) {
        var phoneNumber = data.user;
        var pwd = data.password;
      
        AdminView.findOne({where: {phoneNumber: phoneNumber,password: pwd}}, function(err, res) {
            if(res){
                var adminWalletView = "select phone_number,wallet_balance from ADMIN_VIEW";
                //console.log("in sql.........",transaction_Table);
        
                datasource.connector.execute(adminWalletView, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }
                    var viewWallet = JSON.stringify({'USERWALLETBALANCE': resultObjects})
                    var response = JSON.parse(viewWallet);
                    cb(null, response)
        
        
                });
            }
            else{
                cb(null,{"message" : "Invalid Account"})
            }
           
        })
    
    }



    AdminView.remoteMethod('UserWalletBalance', {
        http: { path: '/allTxn', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })
}