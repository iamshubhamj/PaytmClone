'use strict';
var path = require('path');
var server = require(path.resolve(__dirname, '../..'));
var request = require('request');
var datasource = server.datasources.loopback;

module.exports = function (PaytmUser) {


    ///////////////////////////// Registration //////////////////////////////


    PaytmUser.Registration = function (data, cb) {
        var otp = Math.floor((Math.random() * 1000000) + 1);
        var phn_Num = data.phoneNumber;
        var password = data.password;
        var email_Id = data.emailId;
        var otp = otp;

        var postData = {
            "phoneNumber": phn_Num,
            "password": password,
            "emailId": email_Id,
            "otp": otp
        }

        var merchant = postData;

        PaytmUser.findOne({ where: { phoneNumber: phn_Num } }, function (err, res) {

            if (res) {

                PaytmUser.upsert(merchant, (err, respo) => {
                    if (err) return err;
                    cb(null, respo);

                });
                var transaction_Table = "UPDATE PAYTM_TRANSACTION SET PAYEE_NUMBER = '" + phn_Num + "'";
                console.log("in sql.........", transaction_Table);

                datasource.connector.execute(transaction_Table, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }



                });

            }
            else {
                console.log("else");
                PaytmUser.create(merchant, (err, respo) => {
                    if (err) return err;
                    cb(null, respo)
                });
                var transaction_Table = "INSERT INTO PAYTM_TRANSACTION (PAYEE_NUMBER) VALUES ('" + phn_Num + "')";
                //console.log("in sql.........",transaction_Table);

                datasource.connector.execute(transaction_Table, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }
                    // QueryMsg = resultObjects;


                });
            }
        });
    }

    PaytmUser.remoteMethod('Registration', {
        http: { path: '/signup', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }
    });




    ///////////////////////////////////  OTP Validation  //////////////////////////////

    PaytmUser.Validation = function (data, cb) {
        var otp = data.otp;


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        PaytmUser.findOne({ where: { otp: otp } }, function (err, res) {

            if (res != null) {
                var response = {
                    "PhoneNumber": res.phoneNumber,
                    "Message": "OTP Validation Done.",
                    "Status": "Success"
                };
                cb(null, response)
            } else {

                cb(null, { "Message": "Invalid OTP.", "Status": "Fail" });
                return cb;

            }



        }
        )
    }


    PaytmUser.remoteMethod('Validation', {
        http: { path: '/otp_Validation', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })


    ////////////////////////////////// Login User //////////////////////////////////


    PaytmUser.checkCredentials = function (data, cb) {


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        var phoneNumber = data.phoneNumber;
        var password = data.password;


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        PaytmUser.findOne({ where: { phoneNumber: phoneNumber, password: password } }, function (err, res) {

            if (res != null) {
                var response = {
                    "PhoneNumber": res.phoneNumber,
                    "Status": "Success",
                    "Message": "Login Successfully done."
                };
                cb(null, response)
            } else {

                cb(null, { "Message": "Login Failed. Please check Credentials." });
                return;

            }


        }
        )
    }


    PaytmUser.remoteMethod('checkCredentials', {
        http: { path: '/login', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })

    ////////////////////////////////// Add Money ////////////////////////////////


    PaytmUser.AddMoney = function (data, cb) {
        var phoneNumber = data.phoneNumber;
        var walletBalance = data.addBalance;

        var addBalData = {
            "phoneNumber": phoneNumber,
            "walletBalance": walletBalance
        }
        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        PaytmUser.findOne({ where: { phoneNumber: phoneNumber } }, function (err, res) {

            if (res) {
                PaytmUser.upsert(addBalData, (err, respo) => {
                    if (err) return err;
                    cb(null, respo);

                });
/*
It will load all transaction to Admin Schema into Admin_View Table 
*/
                request({
                    method: "POST",
                    url: "https://localhost:3000/api/admin/loadWallet",
                    rejectUnauthorized: false,
                    passphrase: 'admin@123',
                    headers: {
                      "Content-Type": "application/json"
                    }, agentOptions: {
                      secureProtocol: 'TLSv1_2_method'
                    },
                    body: JSON.stringify(addBalData),
                  }, function (error, httpResponse, body) {
                    if (error) {
                      return console.dir(error);
                    }
              
                  });

            }


        }
        )
    }


    PaytmUser.remoteMethod('AddMoney', {
        http: { path: '/add_Money', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })
}