'use strict';
var path = require('path');
var server = require(path.resolve(__dirname, '../..'));
var request = require('request');
var datasource = server.datasources.loopback;

module.exports = function (PaytmTransaction) {



    PaytmTransaction.TransferAmount = function (data, cb) {

        var payerNumber = data.payerNumber;
        var payeeNumber = data.payeeNumber;
        var amount = data.amount;


        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        PaytmTransaction.findOne({ where: { phoneNumber: payeeNumber } }, function (err, res) {

            if (res) {

                var walletBalance = "SELECT WALLET_BALANCE AS BALANCE FROM PAYTM_USER WHERE PHONE_NUMBER = '" + payerNumber + "'";
                //console.log("in sql.........",transaction_Table);

                datasource.connector.execute(walletBalance, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }
                    var bal = resultObjects[0].BALANCE;

                    var amountData = {
                        "payerNumber": payerNumber,
                        "payeeNumber": payeeNumber,
                        "transferAmount": amount,
                        "payerWalletBalance": bal
                    }

                    if (bal > amount) {
                        PaytmTransaction.create(amountData, (err, respo) => {
                            if (err) return err;
                            cb(null, respo)
                        });
                        var updateBal = bal - amount
                        var addBalData = {
                            "phoneNumber": payerNumber,
                            "walletBalance": updateBal
                        }

                        /*
It will load all transaction to Admin Schema into Admin_View Table 
*/

                        request({
                            method: "POST",
                            url: "https://localhost:3000/api/admin/loadWallet",
                            rejectUnauthorized: false,
                            passphrase: 'admin@123',
                            headers: {
                                "Content-Type": "application/json"
                            }, agentOptions: {
                                secureProtocol: 'TLSv1_2_method'
                            },
                            body: JSON.stringify(addBalData),
                        }, function (error, httpResponse, body) {
                            if (error) {
                                return console.dir(error);
                            }

                        });


                        var updateBalance = "UPDATE PAYTM_USER SET WALLET_BALANCE = '" + updateBal + "' WHERE PHONE_NUMBER = '" + payerNumber + "'";
                        console.log("in sql.........", updateBalance);

                        datasource.connector.execute(updateBalance, null, (err, resultObjects) => {
                            if (err) {
                                return err;
                            }


                        })
                    } else {

                        cb(null, { "message": "Please add amount in your Acount." })
                    }




                });

            }
        }
        )
    }


    PaytmTransaction.remoteMethod('TransferAmount', {
        http: { path: '/transfer_Amount', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })

    ////////////////////////////// TXN History ///////////////////////////////////


    PaytmTransaction.TxnHistory = function (data, cb) {


        var payeeNumber = data.payeeNumber;



        //console.log("account num : "+accId + "password : "+pwd+" userName :"+uname);

        PaytmTransaction.findOne({ where: { phoneNumber: payeeNumber } }, function (err, res) {

            if (res) {
                var txnHistoryDetails = "SELECT TRANSFER_AMOUNT,CREATED_ON FROM PAYTM_TRANSACTION WHERE PAYER_NUMBER = '" + payeeNumber + "'";


                datasource.connector.execute(txnHistoryDetails, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }
                    var txnRouter = JSON.stringify({ 'TXNHISTORY': resultObjects })
                    var response = JSON.parse(txnRouter);
                    cb(null, response)
                })

            } else {
                cb(null, { "message": "something went wrong." })
            }
        }
        )
    }


    PaytmTransaction.remoteMethod('TxnHistory', {
        http: { path: '/txnHistory', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }

    })


}